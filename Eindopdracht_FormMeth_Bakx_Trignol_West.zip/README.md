# Formele Methoden (Formal Language Theory)
Exercises of the school subject "Formele Methoden" (Dormal Language Theory) in which we play with automatons, regular expressions and lexical analysis.
